rm(list=ls(all=TRUE));
set.seed(4000);
nClass <- 2;
nSubPerClass <- 3;
nObsPerSub <- 4;
png(height=5,width=5,units="in",res=600,file="FigXShapeDemo.png");
class <- rep(1:2,each=nSubPerClass*nObsPerSub);
subject <- rep(1:(nSubPerClass*nClass),each=nObsPerSub);
b0 <- rep(NA,length(subject));
b1 <- rep(NA,length(subject));
time <- rep(NA,length(subject));
for (i in 1:(nSubPerClass*nClass)) {
  time[which(subject==i)] <- sort(runif(nObsPerSub));
}
b0[which(class==1)] <-  1;
b0[which(class==2)] <- -1;
b1[which(class==1)] <- -2;
b1[which(class==2)] <-  2;
y <- b0+b1*time+.1*rnorm(length(time));
for (i in 1:(nSubPerClass*nClass)) {
  y[which(subject==i)] <- y[which(subject==i)]+.2*rnorm(1);
}
false.class <- y > 0;
par(mfrow=c(2,2));
# Raw data
par(mar = c(2,2,3,1));
par(mgp=c(2,.1,0));
par(cex.lab=1.3);
par(cex.axis=1.3);
plot(time,
     y,
     pch=1,
     xlim=c(0,1),
     ylim=c(min(y),max(y)),
     xaxt="n",
     yaxt="n",
     xlab="",
     ylab="");
title(xlab="Time",line=0.5);
title(ylab="Observed Y",line=0.5);
title(main=expression("(A) Observed Scatterplot"));
# Raw data and true classes
plot(time,
     y,
     pch=2+15*(class==max(class)),
     xlim=c(0,1),
     ylim=c(min(y),max(y)),
     xaxt="n",
     yaxt="n",
     xlab="",
     ylab="");
title(main=expression("(B)  Plausible Class Structure"));
title(xlab="Time",line=0.5);
title(ylab="Observed Y",line=0.5);
for (k in 1:2) {
   abline(a=lm(y[which(class==k)]~time[which(class==k)])$coef[1],
          b=lm(y[which(class==k)]~time[which(class==k)])$coef[2],
          lty="dotted",lwd=2);
}
# Raw data and false classes
plot(time,
     y,
     pch=2+15*(false.class==max(false.class)),
     xlim=c(0,1),
     ylim=c(min(y),max(y)),
     xaxt="n",
     yaxt="n",
     xlab="",
     ylab="");
v <- seq(min(time),max(time),length=1000);
lines(v,.1+4*(v-.5)^2,lty="dotted",lwd=2);
lines(v,-.1-4*(v-.5)^2,lty="dotted",lwd=2);
title(xlab="Time",line=0.5);
title(ylab="Observed Y",line=0.5);
title(main=expression("(C)  Another Possible Structure"));
# Connected raw data shows true classes
plot(time[which(subject==1)],
     y[which(subject==1)],
     pch=1,
     type="n",
     xlim=c(0,1),
     ylim=c(min(y),max(y)),
     xaxt="n",
     yaxt="n",
     xlab="",
     ylab="");
text(time[which(subject==1)],
     y[which(subject==1)],
     labels="1");
title(xlab="Time",line=0.5);
title(ylab="Observed Y",line=0.5);
title(main=expression("(D)  Plot by Subject "));
lines(time[which(subject==1)],
     y[which(subject==1)]);
for (i in 2:(nSubPerClass*nClass)) {
  text(time[which(subject==i)],
       y[which(subject==i)],pch=1,
     labels=i);
  lines(time[which(subject==i)],
       y[which(subject==i)]);
}
v <- seq(0,1,length=1000);
dev.off();