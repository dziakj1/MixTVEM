rm(list=ls(all=TRUE));
fit.stats <- NULL;
for (theNumClasses in 1:8) {
    load(paste("Save-FirstModel-",theNumClasses,".rdata",sep=""));
    fit.stats <- rbind(fit.stats,
                       c( theNumClasses,
                          ans1$bestFit$enp,
                          ans1$bestFit$logLik,
                          ans1$bestFit$aic,
                          ans1$bestFit$bic,
                          ans1$bestFit$weightedRSS,
                          sum(ans1$logLikBySeed>max(ans1$logLikBySeed)-.1)-1));
}
print(fit.stats);
plot(fit.stats[,6]);

