rm(list=ls(all=TRUE));
graphics.off();
load("Save-FirstModel-3.rdata");
start.time <- Sys.time();
source("MixTVEM.r");
theNumClasses <- 3;
covariates <- read.table("SubjectData.txt",header=TRUE,fill=TRUE);
colnames(covariates)[which(colnames(covariates)=="SUBJECT")] <- "subj";
shiffmanFirstWeekWithCovariates <- merge(x=shiffmanFirstWeek,
                                         y=covariates,
                                         by="subj");
low.index <- order(apply(ans1$bestFit$fittedY,2,mean),decreasing=FALSE)[1];
med.index <- order(apply(ans1$bestFit$fittedY,2,mean),decreasing=FALSE)[2];
high.index <- order(apply(ans1$bestFit$fittedY,2,mean),decreasing=FALSE)[3];
low.class <- which(apply(ans1$bestFit$postProbsBySub,1,which.max)==low.index);
med.class <- which(apply(ans1$bestFit$postProbsBySub,1,which.max)==med.index);
high.class <- which(apply(ans1$bestFit$postProbsBySub,1,which.max)==high.index);


avecigs.by.subject <- rep(NA,200);
mintofir.by.subject <- rep(NA,200);
for (i in 1:200) {
   these <- which(shiffmanFirstWeekWithCovariates$subj==unique(shiffmanFirstWeekWithCovariates$subj)[i]);
   avecigs.by.subject[i] <- mean(shiffmanFirstWeekWithCovariates$AVECIGS[these]);
   stopifnot(sd(shiffmanFirstWeekWithCovariates$AVECIGS[these])==0);
   mintofir.by.subject[i] <- mean(shiffmanFirstWeekWithCovariates$MINTOFIR[these]);
   stopifnot(sd(shiffmanFirstWeekWithCovariates$MINTOFIR[these])==0);
}

print(summary(avecigs.by.subject[low.class]));
print(summary(avecigs.by.subject[med.class]));
print(summary(avecigs.by.subject[high.class]));

print(summary(mintofir.by.subject[low.class]));
print(summary(mintofir.by.subject[med.class]));
print(summary(mintofir.by.subject[high.class]));
