rm(list=ls(all=TRUE));
graphics.off();
################ First Model #########################
load("Save-FirstModel-3-WithSEs.rdata");
gamma <- ans1$bestFit$gamma;
cov.gamma <- ans1$covarMats$sandwichCovarianceThetaGamma[drop(ans1$covarMats$gammaIndex),
                                                         drop(ans1$covarMats$gammaIndex)];
p <- as.vector(exp(gamma)/sum(exp(gamma)));
for (j in 1:3) {
    partial.pj.partial.gamma2 <- ifelse(j==2,p[j]*(1-p[j]),-p[j]*p[2]);
    partial.pj.partial.gamma3 <- ifelse(j==2,p[j]*(1-p[j]),-p[j]*p[3]);
    jacobian <- cbind(partial.pj.partial.gamma2,partial.pj.partial.gamma3);
    var.pj <- jacobian%*%cov.gamma%*%t(jacobian);
    margin.of.error.j <- sqrt(var.pj)*1.96;
    print(c(p[j]-margin.of.error.j,
            p[j]+margin.of.error.j));
}

################ Second Model #########################
rm(list=ls(all=TRUE));
load("Save-SecondModel-3-WithSEs.rdata");
gamma <- ans1$bestFit$gamma;
cov.gamma <- ans1$covarMats$sandwichCovarianceThetaGamma[drop(ans1$covarMats$gammaIndex),
                                                         drop(ans1$covarMats$gammaIndex)];
p <- as.vector(exp(gamma)/sum(exp(gamma)));
for (j in 1:3) {
    partial.pj.partial.gamma2 <- ifelse(j==2,p[j]*(1-p[j]),-p[j]*p[2]);
    partial.pj.partial.gamma3 <- ifelse(j==2,p[j]*(1-p[j]),-p[j]*p[3]);
    jacobian <- cbind(partial.pj.partial.gamma2,partial.pj.partial.gamma3);
    var.pj <- jacobian%*%cov.gamma%*%t(jacobian);
    margin.of.error.j <- sqrt(var.pj)*1.96;
    print(c(p[j]-margin.of.error.j,
            p[j]+margin.of.error.j));
}
