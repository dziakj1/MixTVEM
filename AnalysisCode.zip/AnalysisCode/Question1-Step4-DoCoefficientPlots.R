##### Model Selection #############################################
rm(list=ls(all=TRUE));
png("Figure2ForPaper.png");
bat.colors <- gray(c(0,.25,0,.25,0));
numClasses <- 3;
  load(paste("Save-FirstModel-",numClasses,"-WithSEs.rdata",sep=""));
  class.rank <- rank(ans1$betaByGrid[[1]][1,]);
  class.order <- order(ans1$betaByGrid[[1]][1,]);
  ltypes <- c("dotted","dashed","solid");
  for (class.index in 1:numClasses) {
    if (class.index==1) {
        plot(x=ans1$timeGrid,
             y=ans1$betaByGrid[[1]][,class.index],
             type="l",
             xlim=c(min(ans1$timeGrid),
                    max(ans1$timeGrid)),
             xlab="Time (Days)",
             ylim=c(0,10),
             ylab=expression(paste("Fitted Mean Urge, ",displaystyle(beta[0](t)))),
             main="",
             cex.lab=1.2,
             mgp=c(2.25,1,0),
             lwd=3,
             col=bat.colors[class.rank[class.index]],
             lty=ltypes[class.rank[class.index]]);
      } else {
        lines(x=ans1$timeGrid,
              y=ans1$betaByGrid[[1]][,class.index],
              col=bat.colors[class.rank[class.index]],
              lwd=3,
              lty=ltypes[class.rank[class.index]]);
      }
      lines(x=ans1$timeGrid,
            y=ans1$betaByGrid[[1]][,class.index]-
              1.96*ans1$betaSESandwichByGrid[[1]][,class.index],
            lwd=1/2,
            col=bat.colors[class.rank[class.index]],
            lty=ltypes[class.rank[class.index]]);
      lines(x=ans1$timeGrid,
            y=ans1$betaByGrid[[1]][,class.index]+
              1.96*ans1$betaSESandwichByGrid[[1]][,class.index],
            lwd=1/2,
            col=bat.colors[[class.rank[class.index]]],
            lty=ltypes[[class.rank[class.index]]]);
  }
  descriptive.classes <- c("Rapidly Declining","Gradually Declining","Consistently High");
  legend(x="topright",
         lwd=3,
         col=bat.colors[numClasses:1],
         lty=ltypes[numClasses:1],
         ncol=ifelse(numClasses==3,1,2),
         legend=paste(descriptive.classes[numClasses:1],
                      " Class ",
                      "(",
                      round(100*ans1$bestFit$fittedProb[1,class.order[numClasses:1]]),
                      "%)",sep=""));

dev.off();