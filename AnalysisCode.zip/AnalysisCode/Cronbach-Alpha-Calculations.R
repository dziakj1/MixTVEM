rm(list=ls(all=TRUE));
graphics.off();
load("Shiffman.rdata");
library(psychometric);
set.seed(46);
par(mfrow=c(4,2));
hist(shiffmanFirstWeek$miserable);
hist(shiffmanFirstWeek$irritable);
hist(shiffmanFirstWeek$tense);
hist(shiffmanFirstWeek$frustr.ang);
hist(shiffmanFirstWeek$sad);
hist(shiffmanFirstWeek$rev.happy);
hist(shiffmanFirstWeek$rev.contented);
table(shiffmanFirstWeek$miserable);
table(shiffmanFirstWeek$irritable);
table(shiffmanFirstWeek$tense);
table(shiffmanFirstWeek$frustr.ang);
table(shiffmanFirstWeek$sad);
table(shiffmanFirstWeek$rev.happy);
table(shiffmanFirstWeek$rev.contented);
emotions <- cbind(shiffmanFirstWeek$miserable,
                  shiffmanFirstWeek$irritable,
                  shiffmanFirstWeek$tense,
                  shiffmanFirstWeek$frustr.ang,
                  shiffmanFirstWeek$sad,
                  shiffmanFirstWeek$rev.happy,
                  shiffmanFirstWeek$rev.contented);
print(alpha(emotions));
print(alpha.CI(alpha(emotions),
      ncol(emotions),
      nrow(emotions),
      level=.95,
      onesided = FALSE));

first.rows <- NULL;
for (this.subject in names(table(shiffmanFirstWeek$subj))[which(table(shiffmanFirstWeek$subj)>0)]) {
  these <- which(shiffmanFirstWeek$subj==this.subject);
  this.subjects.first.row <-  these[which.min(shiffmanFirstWeek$Time[these])];
  first.rows <- c(first.rows, this.subjects.first.row);
}
print(alpha(emotions[first.rows,]));
print(alpha.CI(alpha(emotions[first.rows,]),
      ncol(emotions[first.rows,]),
      nrow(emotions[first.rows,]),
      level=.95,
      onesided = FALSE));


random.rows <- NULL;
for (this.subject in names(table(shiffmanFirstWeek$subj))[which(table(shiffmanFirstWeek$subj)>0)]) {
  these <- which(shiffmanFirstWeek$subj==this.subject);
  this.subjects.random.row <-  sample(these,size=1);
  random.rows <- c(random.rows, this.subjects.random.row);
}
print(alpha(emotions[random.rows,]));
print(alpha.CI(alpha(emotions[random.rows,]),
      ncol(emotions[random.rows,]),
      nrow(emotions[random.rows,]),
      level=.95,
      onesided = FALSE));


random.rows <- NULL;
for (this.subject in names(table(shiffmanFirstWeek$subj))[which(table(shiffmanFirstWeek$subj)>0)]) {
  these <- which(shiffmanFirstWeek$subj==this.subject);
  this.subjects.random.row <-  sample(these,size=1);
  random.rows <- c(random.rows, this.subjects.random.row);
}
print(alpha(emotions[random.rows,]));
print(alpha.CI(alpha(emotions[random.rows,]),
      ncol(emotions[random.rows,]),
      nrow(emotions[random.rows,]),
      level=.95,
      onesided = FALSE));


random.rows <- NULL;
for (this.subject in names(table(shiffmanFirstWeek$subj))[which(table(shiffmanFirstWeek$subj)>0)]) {
  these <- which(shiffmanFirstWeek$subj==this.subject);
  this.subjects.random.row <-  sample(these,size=1);
  random.rows <- c(random.rows, this.subjects.random.row);
}
print(alpha(emotions[random.rows,]));
print(alpha.CI(alpha(emotions[random.rows,]),
      ncol(emotions[random.rows,]),
      nrow(emotions[random.rows,]),
      level=.95,
      onesided = FALSE));