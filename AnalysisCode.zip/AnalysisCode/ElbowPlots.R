first <- c(41298.4,37473.4,28673.7,25277.3,23715.7,22300.8,21629.7);
second <- c(33493.8,32206.3,22897.5,21823,20122.9,18999.7,18897.9);
plot(1:7,first/1000,
     type="l",
     xlab="Classes",
     ylab="Weighted RSS / 1000");
points(1:7,first/1000,pch=16);

plot(1:7,second/1000,
     type="l",
     xlab="Classes",
     ylab="Weighted RSS / 1000");
points(1:7,second/1000,pch=16);
