rm(list=ls(all=TRUE));
graphics.off();
load("Shiffman.rdata");
set.seed(200);
start.time <- Sys.time();
source("MixTVEM.r");
for (theNumClasses in 1:8) {
    png(filename=paste("Plot",theNumClasses,".png",sep=""));
    ans1 <- TVEMMixNormal( id=as.integer(shiffmanFirstWeek$subj),
                     time=shiffmanFirstWeek$Time,
                     dep=shiffmanFirstWeek$urge,
                     doPlot=TRUE,
                     numInteriorKnots=6,
                     numClasses=theNumClasses,
                     convergenceCriterion=1e-6,
                     tcov=cbind(1,
                                shiffmanFirstWeek$xNA-mean(shiffmanFirstWeek$xNA)),
                     numStarts=50,
                     getSEs=FALSE );
    save.image(paste("Save",theNumClasses,".rdata",sep=""));
    dev.off();
}
stop.time <- Sys.time();


