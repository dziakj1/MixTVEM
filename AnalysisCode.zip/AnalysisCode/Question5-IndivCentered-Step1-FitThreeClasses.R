rm(list=ls(all=TRUE));
graphics.off();
load("Shiffman.rdata");
set.seed(100);
start.time <- Sys.time();
source("MixTVEM.r");
theNumClasses <- 3;
    png(filename=paste("Plot-IndivCentered-",theNumClasses,"-WithSEs.png",sep=""));
    ans1 <- TVEMMixNormal( id=as.integer(shiffmanFirstWeek$subj),
                     time=shiffmanFirstWeek$Time,
                     dep=shiffmanFirstWeek$urge,
                     doPlot=TRUE,
                     numInteriorKnots=6,
                     numClasses=theNumClasses,
                     convergenceCriterion=1e-8,
                     scov=shiffmanFirstWeek$SubjectPrequitNAMean,
                     tcov=cbind(rep(1,length(shiffmanFirstWeek$xNA)),
                                shiffmanFirstWeek$xNA-shiffmanFirstWeek$SubjectPrequitNAMean),
                     numStarts=50,
                     getSEs=TRUE );
    save.image(paste("Save-IndivCentered-",theNumClasses,"-WithSEs.rdata",sep=""));
    dev.off();
