rm(list=ls(all=TRUE));
graphics.off();
load("Shiffman.rdata");
set.seed(46);
start.time <- Sys.time();
source("MixTVEM.r");
theNumClasses <- 3;
#debug(TVEMMixNormal);
    png(filename=paste("Plot-FirstModel-",theNumClasses,"-WithSEs.png",sep=""));
    ans1 <- TVEMMixNormal( id=as.integer(shiffmanFirstWeek$subj),
                     time=shiffmanFirstWeek$Time,
                     dep=shiffmanFirstWeek$urge,
                     doPlot=TRUE,
                     numInteriorKnots=6,
                     numClasses=theNumClasses,
                     convergenceCriterion=1e-8,
                     tcov=rep(1,nrow(shiffmanFirstWeek)),
                     numStarts=20,
                     getSEs=TRUE );
    save.image(paste("Save-FirstModel-",theNumClasses,"-WithSEs.rdata",sep=""));
    dev.off();
