rm(list=ls(all=TRUE));
graphics.off();
load("Shiffman.rdata");
set.seed(100);
start.time <- Sys.time();
source("MixTVEM.r");
theNumClasses <- 3;
covariates <- read.table("SubjectData.txt",header=TRUE,fill=TRUE);
colnames(covariates)[which(colnames(covariates)=="SUBJECT")] <- "subj";
shiffmanFirstWeekWithCovariates <- merge(x=shiffmanFirstWeek,
                                         y=covariates,
                                         by="subj");
ans1 <- TVEMMixNormal( id=as.integer(shiffmanFirstWeekWithCovariates$subj),
                 time=shiffmanFirstWeekWithCovariates$Time,
                 dep=shiffmanFirstWeekWithCovariates$urge,
                 doPlot=TRUE,
                 numInteriorKnots=6,
                 numClasses=theNumClasses,
                 convergenceCriterion=1e-8,
                 scov=shiffmanFirstWeekWithCovariates$AVECIGS,
                 tcov=rep(1,length(shiffmanFirstWeekWithCovariates$xNA)),
                 numStarts=20,
                 getSEs=TRUE );
print(apply(ans1$beta[[1]],2,mean));
# Reference class 1 came out as the medium class.
gamma.HighVersusLow <- ans1$logisticRegOutput$Estimate[2] - ans1$logisticRegOutput$Estimate[4];
sd.HighVersusLow <- drop(sqrt(c(1,-1)%*%(ans1$ covarMats$sandwichCovarianceThetaGamma[ans1$covarMats$gammaIndex[2,],ans1$covarMats$gammaIndex[2,]])%*%c(1,-1)));
print(ans1$logisticRegOutput);
print(gamma.HighVersusLow/sd.HighVersusLow);

ans2 <- TVEMMixNormal( id=as.integer(shiffmanFirstWeekWithCovariates$subj),
                 time=shiffmanFirstWeekWithCovariates$Time,
                 dep=shiffmanFirstWeekWithCovariates$urge,
                 doPlot=TRUE,
                 numInteriorKnots=6,
                 numClasses=theNumClasses,
                 convergenceCriterion=1e-8,
                 scov=shiffmanFirstWeekWithCovariates$MINTOFIR,
                 tcov=rep(1,length(shiffmanFirstWeekWithCovariates$xNA)),
                 numStarts=20,
                 getSEs=TRUE );
print(apply(ans2$beta[[1]],2,mean));
# Reference class 1 came out as the medium class.
gamma.HighVersusLow <- ans2$logisticRegOutput$Estimate[2] - ans2$logisticRegOutput$Estimate[4];
sd.HighVersusLow <- drop(sqrt(c(1,-1)%*%(ans2$ covarMats$sandwichCovarianceThetaGamma[ans2$covarMats$gammaIndex[2,],ans2$covarMats$gammaIndex[2,]])%*%c(1,-1)));
print(ans2$logisticRegOutput);
print(gamma.HighVersusLow/sd.HighVersusLow);

ans3 <- TVEMMixNormal( id=as.integer(shiffmanFirstWeekWithCovariates$subj),
                 time=shiffmanFirstWeekWithCovariates$Time,
                 dep=shiffmanFirstWeekWithCovariates$urge,
                 doPlot=TRUE,
                 numInteriorKnots=6,
                 numClasses=theNumClasses,
                 convergenceCriterion=1e-8,
                 scov=log(shiffmanFirstWeekWithCovariates$MINTOFIR),
                 tcov=rep(1,length(shiffmanFirstWeekWithCovariates$xNA)),
                 numStarts=20,
                 getSEs=TRUE );
print(apply(ans3$beta[[1]],2,mean));
# Reference class 1 came out as the medium class.
gamma.HighVersusLow <- ans3$logisticRegOutput$Estimate[2] - ans3$logisticRegOutput$Estimate[4];
sd.HighVersusLow <- drop(sqrt(c(1,-1)%*%(ans3$ covarMats$sandwichCovarianceThetaGamma[ans3$covarMats$gammaIndex[2,],ans3$covarMats$gammaIndex[2,]])%*%c(1,-1)));
print(ans3$logisticRegOutput);
print(gamma.HighVersusLow/sd.HighVersusLow);

save.image(paste("Save-Question3a.rdata",sep=""));