rm(list=ls(all=TRUE));
graphics.off();
load("Shiffman.rdata");
set.seed(100);
start.time <- Sys.time();
source("MixTVEM.r"); 
for (theNumClasses in 1:8) {
    png(filename=paste("Plot-FirstModel-",theNumClasses,".png",sep=""));
    ans1 <- TVEMMixNormal( id=as.integer(shiffmanFirstWeek$subj),
                     time=shiffmanFirstWeek$Time,
                     dep=shiffmanFirstWeek$urge,
                     doPlot=TRUE,
                     numInteriorKnots=6,
                     numClasses=theNumClasses,
                     convergenceCriterion=1e-8, 
                     tcov=rep(1,nrow(shiffmanFirstWeek)), 
                     numStarts=50, 
                     getSEs=FALSE );
    save.image(paste("Save-FirstModel-",theNumClasses,".rdata",sep=""));
    dev.off();
}
stop.time <- Sys.time();


