rm(list=ls(all=TRUE));
graphics.off();
load("Shiffman.rdata");
set.seed(46);
start.time <- Sys.time();
source("MixTVEM.r");
theNumClasses <- 3;
answers <- list();
index <- 0;
ds <- rep(0,6);
ks <- rep(0,6);
png(file="KnotComparison.png",
      height=7,
      width=4.5,
      res=720,
      units="in");
for (d in 2:3) {
   for (k in c(2,5,30)) {
     index <- index + 1;
     answers[[index]]<- TVEMMixNormal( id=as.integer(shiffmanFirstWeek$subj),
                     time=shiffmanFirstWeek$Time,
                     dep=shiffmanFirstWeek$urge,
                     doPlot=TRUE,
                     deg=d,
                     numInteriorKnots=k,
                     numClasses=theNumClasses,
                     convergenceCriterion=1e-8,
                     tcov=rep(1,nrow(shiffmanFirstWeek)),
                     numStarts=25,
                     getSEs=FALSE );
    ds[index] <- d;
    ks[index] <- k;
    }
}

par(mfcol=c(3,2),mgp=c(1.6,.7,0),mar=c(2.8,2.6,1.2,.4));
for (index in 1:6) {
   name <- ifelse(ds[index]==2,"Quadratic","Cubic");
   name <- paste(name, ", ",ks[index], " Knots",sep="");
   plot(answers[[index]]$timeGrid,
        answers[[index]]$betaByGrid[[1]][,1],
        type="l",ylim=c(0,7),
        xlab="Time (Days)",ylab="Urge",
        main=name);
   lines(answers[[index]]$timeGrid,
        answers[[index]]$betaByGrid[[1]][,2]);
   lines(answers[[index]]$timeGrid,
        answers[[index]]$betaByGrid[[1]][,3]);
   print(str(answers[[index]]$bestFit$theta));
   print(answers[[index]]$bestFit$fittedProb[1,]);
}
