rm(list=ls(all=TRUE));                                                            
png(height=3,width=5,units="in",res=600,file="Hills.png");
load("Save-FirstModel-3-WithSEs.rdata");
par(mar = .55*c(5,8,3,.5)+.1);
par(mex= 1);
par(las=1);
par(mgp=c(1.5,.1,0));
par(cex.axis=.8);
par(cex.main=1);
par(tck=.01); 
the.times <- ans1$time[order(ans1$time)];
the.hills <- ans1$timeBasis[order(ans1$time),];
plot(the.times,the.hills[,1],
    type="n",
    xlim=c(-1,8),
    ylim=c(0,.9),
    xlab="Time (days)",
    ylab="B-Spline Bases",
    cex.lab=1.2,
    cex.axis=1.1,
    xaxt="n",
    yaxt="n");
for (i in 1:10) {
    lines(the.times,the.hills[,i]);
}
lines(the.times-3,the.hills[,4],lty="dashed");
lines(the.times-2,the.hills[,4],lty="dashed");
lines(the.times-1,the.hills[,4],lty="dashed");
lines(the.times+1,the.hills[,7],lty="dashed");
lines(the.times+2,the.hills[,7],lty="dashed");
lines(the.times+3,the.hills[,7],lty="dashed");
for (i in 1:10) {print(min(the.times[which(the.hills[,i]>0)]));}
for (i in 1:10) {text(-2.1+i,.7,bquote(B[.(i)]));}
axis(side=1,at=0:7);
axis(side=2,at=c(0,.2,.4,.6,.8)); 
dev.off();
print(the.times[c(702,703)]);
print(the.hills[c(702,703),]);