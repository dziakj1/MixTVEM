##### Model Selection #############################################
rm(list=ls(all=TRUE));
load("C:\\Users\\jjd264\\Documents\\RMixTvem\\Question1\\No-X-Class-Members.rdata");
low.class.no.x <- low.class;
med.class.no.x <- med.class;
high.class.no.x <- high.class;
load("Save3.rdata");
low.index <- order(apply(ans1$beta[[1]],2,mean),decreasing=FALSE)[1];
med.index <- order(apply(ans1$beta[[1]],2,mean),decreasing=FALSE)[2];
high.index <- order(apply(ans1$beta[[1]],2,mean),decreasing=FALSE)[3];
low.class <- which(apply(ans1$bestFit$postProbsBySub,1,which.max)==low.index);
med.class <- which(apply(ans1$bestFit$postProbsBySub,1,which.max)==med.index);
high.class <- which(apply(ans1$bestFit$postProbsBySub,1,which.max)==high.index);
no.x.class.membership <- rep(NA,200);
no.x.class.membership[low.class.no.x] <- "1low";
no.x.class.membership[med.class.no.x] <- "2med";
no.x.class.membership[high.class.no.x] <- "3high";
class.membership <- rep(NA,200);
class.membership[low.class] <- "1low";
class.membership[med.class] <- "2med";
class.membership[high.class] <- "3high";
print(table(no.x.class.membership,class.membership));
tgrid <- seq(0,7,length=200);
# High plot
high.class.t <- NULL;
high.class.x <- NULL;
high.class.y <- NULL;
for (i in high.class) {
  these <- which(as.integer(shiffmanFirstWeek$subj)==unique(as.integer(shiffmanFirstWeek$subj))[i]);
  high.class.t <- c(high.class.t,shiffmanFirstWeek$Time[these]);
  high.class.x <- c(high.class.x,shiffmanFirstWeek$xNA[these]);
  high.class.y <- c(high.class.y,shiffmanFirstWeek$urge[these]);
}
model.high.x <- loess(high.class.x~high.class.t);
model.high.y <- loess(high.class.y~high.class.t);
png(file="Question2DescriptiveHigh.png",
    height=1.8,
    width=5,
    res=720,
    units="in");
par(mfrow=c(1,2),mgp=c(1.5,.5,0),mar=c(3,3,1,1));
plot(tgrid,predict(model.high.x,data.frame(high.class.t=tgrid)),type="l",xlim=c(0,7),ylim=c(1,4),xlab="Time",ylab="NegAff");
points(high.class.t,high.class.x,col="gray",pch=19,cex=.75);
lines(tgrid,predict(model.high.x,data.frame(high.class.t=tgrid)),lwd=3);
plot(tgrid,predict(model.high.y,data.frame(high.class.t=tgrid)),type="l",xlim=c(0,7),ylim=c(0,10),xlab="Time",ylab="Urge");
points(high.class.t,high.class.y,col="gray",pch=19,cex=.75);
lines(tgrid,predict(model.high.y,data.frame(high.class.t=tgrid)),lwd=3);
dev.off();
# Medium plot
med.class.t <- NULL;
med.class.x <- NULL;
med.class.y <- NULL;
for (i in med.class) {
  these <- which(as.integer(shiffmanFirstWeek$subj)==unique(as.integer(shiffmanFirstWeek$subj))[i]);
  med.class.t <- c(med.class.t,shiffmanFirstWeek$Time[these]);
  med.class.x <- c(med.class.x,shiffmanFirstWeek$xNA[these]);
  med.class.y <- c(med.class.y,shiffmanFirstWeek$urge[these]);
}
model.med.x <- loess(med.class.x~med.class.t);
model.med.y <- loess(med.class.y~med.class.t);
png(file="Question2DescriptiveMed.png",
    height=1.8,
    width=5,
    res=720,
    units="in");
par(mfrow=c(1,2),mgp=c(1.5,.5,0),mar=c(3,3,1,1));
plot(tgrid,predict(model.med.x,data.frame(med.class.t=tgrid)),type="l",xlim=c(0,7),ylim=c(1,4),xlab="Time",ylab="NegAff");
points(med.class.t,med.class.x,col="gray",pch=19,cex=.75);
lines(tgrid,predict(model.med.x,data.frame(med.class.t=tgrid)),lwd=3);
plot(tgrid,predict(model.med.y,data.frame(med.class.t=tgrid)),type="l",xlim=c(0,7),ylim=c(0,10),xlab="Time",ylab="Urge");
points(med.class.t,med.class.y,col="gray",pch=19,cex=.75);
lines(tgrid,predict(model.med.y,data.frame(med.class.t=tgrid)),lwd=3);
dev.off();
# Low plot
low.class.t <- NULL;
low.class.x <- NULL;
low.class.y <- NULL;
for (i in low.class) {
  these <- which(as.integer(shiffmanFirstWeek$subj)==unique(as.integer(shiffmanFirstWeek$subj))[i]);
  low.class.t <- c(low.class.t,shiffmanFirstWeek$Time[these]);
  low.class.x <- c(low.class.x,shiffmanFirstWeek$xNA[these]);
  low.class.y <- c(low.class.y,shiffmanFirstWeek$urge[these]);
}
model.low.x <- loess(low.class.x~low.class.t);
model.low.y <- loess(low.class.y~low.class.t);
png(file="Question2DescriptiveLow.png",
    height=1.8,
    width=5,
    res=720,
    units="in");
par(mfrow=c(1,2),mgp=c(1.5,.5,0),mar=c(3,3,1,1));
plot(tgrid,predict(model.low.x,data.frame(low.class.t=tgrid)),type="l",xlim=c(0,7),ylim=c(1,4),xlab="Time",ylab="NegAff");
points(low.class.t,low.class.x,col="gray",pch=19,cex=.75);
lines(tgrid,predict(model.low.x,data.frame(low.class.t=tgrid)),lwd=3);
plot(tgrid,predict(model.low.y,data.frame(low.class.t=tgrid)),type="l",xlim=c(0,7),ylim=c(0,10),xlab="Time",ylab="Urge");
points(low.class.t,low.class.y,col="gray",pch=19,cex=.75);
lines(tgrid,predict(model.low.y,data.frame(low.class.t=tgrid)),lwd=3);
dev.off();

# Investigate the unusual class switchers;
switchers <- NULL;
for (i in 1:200) {
  if (i%in%low.class.no.x & i%in%high.class) {switchers <- c(switchers,i);}
}
switchers.t <- NULL;
switchers.x <- NULL;
switchers.y <- NULL;
for (i in switchers) {
  these <- which(as.integer(shiffmanFirstWeek$subj)==unique(as.integer(shiffmanFirstWeek$subj))[i]);
  switchers.t <- c(switchers.t,shiffmanFirstWeek$Time[these]);
  switchers.x <- c(switchers.x,shiffmanFirstWeek$xNA[these]);
  switchers.y <- c(switchers.y,shiffmanFirstWeek$urge[these]);
}
model.switchers.x <- loess(switchers.x~switchers.t);
model.switchers.y <- loess(switchers.y~switchers.t);
for (i in switchers) {
  these <- which(as.integer(shiffmanFirstWeek$subj)==unique(as.integer(shiffmanFirstWeek$subj))[i]);
  switchers.t <- c(switchers.t,shiffmanFirstWeek$Time[these]);
  switchers.x <- c(switchers.x,shiffmanFirstWeek$xNA[these]);
  switchers.y <- c(switchers.y,shiffmanFirstWeek$urge[these]);
}
png(file="Question2DescriptiveSwitchers.png",
    height=1.8,
    width=5,
    res=720,
    units="in");
par(mfrow=c(1,2),mgp=c(1.5,.5,0),mar=c(3,3,1,1));
plot(tgrid,predict(model.switchers.x,data.frame(switchers.t=tgrid)),type="l",xlim=c(0,7),ylim=c(1,4),xlab="Time",ylab="NegAff");
points(switchers.t,switchers.x,col="gray",pch=19,cex=.75);
lines(tgrid,predict(model.switchers.x,data.frame(switchers.t=tgrid)),lwd=3);
plot(tgrid,predict(model.switchers.y,data.frame(switchers.t=tgrid)),type="l",xlim=c(0,7),ylim=c(0,10),xlab="Time",ylab="Urge");
points(switchers.t,switchers.y,col="gray",pch=19,cex=.75);
lines(tgrid,predict(model.switchers.y,data.frame(switchers.t=tgrid)),lwd=3);
dev.off();


nonswitchers <- NULL;
for (i in 1:200) {
  if (!(i%in%low.class.no.x) & i%in%high.class) {nonswitchers <- c(nonswitchers,i);}
}
nonswitchers.t <- NULL;
nonswitchers.x <- NULL;
nonswitchers.y <- NULL;
for (i in nonswitchers) {
  these <- which(as.integer(shiffmanFirstWeek$subj)==unique(as.integer(shiffmanFirstWeek$subj))[i]);
  nonswitchers.t <- c(nonswitchers.t,shiffmanFirstWeek$Time[these]);
  nonswitchers.x <- c(nonswitchers.x,shiffmanFirstWeek$xNA[these]);
  nonswitchers.y <- c(nonswitchers.y,shiffmanFirstWeek$urge[these]);
}
model.nonswitchers.x <- loess(nonswitchers.x~nonswitchers.t);
model.nonswitchers.y <- loess(nonswitchers.y~nonswitchers.t);
for (i in nonswitchers) {
  these <- which(as.integer(shiffmanFirstWeek$subj)==unique(as.integer(shiffmanFirstWeek$subj))[i]);
  nonswitchers.t <- c(nonswitchers.t,shiffmanFirstWeek$Time[these]);
  nonswitchers.x <- c(nonswitchers.x,shiffmanFirstWeek$xNA[these]);
  nonswitchers.y <- c(nonswitchers.y,shiffmanFirstWeek$urge[these]);
}
png(file="Question2DescriptiveNonswitchers.png",
    height=1.8,
    width=5,
    res=720,
    units="in");
par(mfrow=c(1,2),mgp=c(1.5,.5,0),mar=c(3,3,1,1));
plot(tgrid,predict(model.nonswitchers.x,data.frame(nonswitchers.t=tgrid)),type="l",xlim=c(0,7),ylim=c(1,4),xlab="Time",ylab="NegAff");
points(nonswitchers.t,nonswitchers.x,col="gray",pch=19,cex=.75);
lines(tgrid,predict(model.nonswitchers.x,data.frame(nonswitchers.t=tgrid)),lwd=3);
plot(tgrid,predict(model.nonswitchers.y,data.frame(nonswitchers.t=tgrid)),type="l",xlim=c(0,7),ylim=c(0,10),xlab="Time",ylab="Urge");
points(nonswitchers.t,nonswitchers.y,col="gray",pch=19,cex=.75);
lines(tgrid,predict(model.nonswitchers.y,data.frame(nonswitchers.t=tgrid)),lwd=3);
dev.off();


print(c(length(low.class.t),
        length(med.class.t),
        length(high.class.t),
        length(nonswitchers.t),
        length(switchers.t)));
print(c(mean(low.class.t),
        mean(med.class.t),
        mean(high.class.t),
        mean(nonswitchers.t),
        mean(switchers.t)));
print(c(mean(low.class.x),
        mean(med.class.x),
        mean(high.class.x),
        mean(nonswitchers.x),
        mean(switchers.x)));
print(c(sd(low.class.x),
        sd(med.class.x),
        sd(high.class.x),
        sd(nonswitchers.x),
        sd(switchers.x)));
print(c(mean(low.class.y),
        mean(med.class.y),
        mean(high.class.y),
        mean(nonswitchers.y),
        mean(switchers.y)));
print(c(sd(low.class.y),
        sd(med.class.y),
        sd(high.class.y),
        sd(nonswitchers.y),
        sd(switchers.y)));
print(c(cor(low.class.x,low.class.y),
        cor(med.class.x,med.class.y),
        cor(high.class.x,high.class.y),
        cor(nonswitchers.x,nonswitchers.y),
        cor(switchers.x,switchers.y)));


