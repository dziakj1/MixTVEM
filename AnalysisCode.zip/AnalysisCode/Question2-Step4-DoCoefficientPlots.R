##### Model Selection #############################################
rm(list=ls(all=TRUE));
png(file="Figure3ForPaper.png",
    height=7,
    width=5,
    res=720,
    units="in");
############## 3-Class Plot #############################################
rm(list=ls(all=TRUE));
bat.colors <- gray(c(0,.25,0));
par(mfrow=c(2,1),mar=c(4,4,2,2),mgp=c(2.1,1,0));
numClasses <- 3;
load(paste("Save-SecondModel-3-WithSEs.rdata",sep=""));
class.rank <- rank(ans1$betaByGrid[[1]][1,]);
  class.order <- order(ans1$betaByGrid[[1]][1,]);
  ltypes <- c("dotted","dashed","solid");
for (which.coefficient in 1:2) {
  if (which.coefficient==1) {
    ymin <- 0;
    ymax <- 8;
    title1 <- "Fitted Mean Adjusted Urge Trajectories";
    title2 <- expression(displaystyle(beta[0,c](t)));
  };
  if (which.coefficient==2) {
    ymin <- -1;
    ymax <- +3;
    title1 <- "Time-Specific Relationships \n of Negative Affect to Urge";
    title2 <- expression(displaystyle(beta[1,c](t)));
  };
  for (class.index in 1:numClasses) {
    if (class.index==1) {
      plot(x=ans1$timeGrid,
           y=ans1$betaByGrid[[which.coefficient]][,class.index],
           type="l",
           main=title1,
           cex.main=.9,
           xlim=c(min(ans1$timeGrid),
                  max(ans1$timeGrid)),
           xlab="Time (Days)",
           ylim=c(ymin,ymax),
           ylab=title2,
           lwd=3,
           lty=ltypes[class.rank[class.index]],
           col=bat.colors[class.rank[class.index]]);
    } else {
      lines(x=ans1$timeGrid,
            y=ans1$betaByGrid[[which.coefficient]][,class.index],
            lwd=3,
            lty=ltypes[class.rank[class.index]],
            col=bat.colors[class.rank[class.index]])
    }
    lines(x=ans1$timeGrid,
          y=ans1$betaByGrid[[which.coefficient]][,class.index]-
            1.96*ans1$betaSESandwichByGrid[[which.coefficient]][,class.index],
          lwd=1/2,
            col=bat.colors[class.rank[class.index]],
            lty=ltypes[class.rank[class.index]]);
    lines(x=ans1$timeGrid,
          y=ans1$betaByGrid[[which.coefficient]][,class.index]+
            1.96*ans1$betaSESandwichByGrid[[which.coefficient]][,class.index],
          lwd=1/2,
            col=bat.colors[[class.rank[class.index]]],
            lty=ltypes[[class.rank[class.index]]]);
  }
    descriptive.classes <- c("Low Beta0, Low Beta1","Medium Beta0, High Beta1","High Beta0, High Beta1");
    legend(x=ifelse(which.coefficient==1,"topright","bottomright"),
           lwd=3,
             cex=.7,
             col=bat.colors[numClasses:1],
             lty=ltypes[numClasses:1],
             ncol=ifelse(numClasses==3,1,2),
             legend=paste(descriptive.classes[numClasses:1],
                        " (",
                          round(100*ans1$bestFit$fittedProb[1,class.order[numClasses:1]]),
                          "%)",sep=""));
}

dev.off();