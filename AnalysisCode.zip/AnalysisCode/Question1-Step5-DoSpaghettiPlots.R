##### Model Selection #############################################
rm(list=ls(all=TRUE));
windows();
load(paste("Save-FirstModel-3-WithSEs.rdata"));
set.seed(100);
low.index <- order(apply(ans1$bestFit$fittedY,2,mean),decreasing=FALSE)[1];
med.index <- order(apply(ans1$bestFit$fittedY,2,mean),decreasing=FALSE)[2];
high.index <- order(apply(ans1$bestFit$fittedY,2,mean),decreasing=FALSE)[3];
low.class <- which(apply(ans1$bestFit$postProbsBySub,1,which.max)==low.index);
med.class <- which(apply(ans1$bestFit$postProbsBySub,1,which.max)==med.index);
high.class <- which(apply(ans1$bestFit$postProbsBySub,1,which.max)==high.index);
exemplars <- rbind(sample(high.class,4),
                   sample(med.class,4),
                   sample(low.class,4));
save(low.class,med.class,high.class,file="No-X-Class-Members.rdata");
for (i  in 1:3) {
  png(file=paste("Question1Spaghetti",i,".png",sep=""),
      height=1.8,
      width=5,
      res=720,
      units="in");
  par(mfrow=c(1,4),mgp=c(1.5,.5,0),mar=c(2,2,1,1));
  for (j in 1:4) {
     these <- which(as.integer(shiffmanFirstWeek$subj)==unique(as.integer(shiffmanFirstWeek$subj))[exemplars[i,j]]);
     these.time <- shiffmanFirstWeek$Time[these][order(shiffmanFirstWeek$Time[these])];
     these.y <- shiffmanFirstWeek$urge[these][order(shiffmanFirstWeek$Time[these])];
     plot(these.time,these.y,type="l",xlab="",ylab="",xlim=c(0,7),ylim=c(0,10),cex.axis=.8);
     points(these.time,these.y);
     lines(ans1$timeGrid,ans1$betaByGrid[[1]][,c(high.index,med.index,low.index)[i]],lty="dotted");
  }
  dev.off();
}
